let x=10,y=20;
var z=x+y;
console.log("sum of x+y is:",z);
document.write("sum of x+y is:",z);
var p=x-y;
console.log("subtraction is:",p)
document.write("subtraction is:",p);
var p=x*y;
console.log("multiplication is:",p)
document.write("multiplication is:",p);
var p=x/y;
console.log("division is:",p)
document.write("division is:",p);


